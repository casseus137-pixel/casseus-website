# Casseus Backend — Email & Surveys

Pure **Node.js** server (no npm packages required).

- Saves surveys → emails report to **casseus137@gmail.com**
- Notifies owner for corporate requests & Help questions
- Emails admin weekly reports
- Serves the full website

## Start

```bash
cd casseus-website/backend
node server.js
```

Open **http://localhost:3001/**

## API

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/health` | Status + SMTP flag |
| POST | `/api/surveys` | `{ name, email, rating, comment }` |
| GET | `/api/surveys` | List saved surveys |
| POST | `/api/notify` | `{ type, title, fields, replyTo }` |
| POST | `/api/weekly-report` | `{ subject, text, html, week }` |

Stored under `backend/data/*.json`.

## Real email

Edit `backend/.env`:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=casseus137@gmail.com
SMTP_PASS=your-gmail-app-password
OWNER_EMAIL=casseus137@gmail.com
```

Use a Gmail **App Password**. Without SMTP, emails are printed in the server console.

## Frontend

When the site is opened via this server, forms use the API. Opening `index.html` as a file falls back to browser storage.

## Stripe

Set `STRIPE_SECRET_KEY` in `.env`. Endpoints:

- `GET /api/stripe/config`
- `POST /api/stripe/create-checkout-session`
- `GET /api/stripe/session?session_id=`
- `POST /api/stripe/webhook`
